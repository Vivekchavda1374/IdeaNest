console.log(add(10, 5));
console.log(sub(10, 5));
console.log(avg(10, 5));
function add(x, y) {
  return x + y;
}
const sub = (x, y) => x - y;
const avg = (x, y) => {
  c = x + y;
  return c / 2;
};
