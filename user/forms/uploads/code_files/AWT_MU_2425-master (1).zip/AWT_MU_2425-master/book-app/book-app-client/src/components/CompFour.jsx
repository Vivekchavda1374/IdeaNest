import React from "react";

const CompFour = () => {
  return <div>CompFour</div>;
};

export default CompFour;
