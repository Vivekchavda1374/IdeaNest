import React from "react";
import CompThree from "./CompThree";

const CompTwo = () => {
  return (
    <div>
      CompTwo
      <CompThree />
    </div>
  );
};

export default CompTwo;
