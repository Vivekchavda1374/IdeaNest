const create = (params) => {};
const fetchAll = (params) => {};
const findOne = (params) => {};
const update = (params) => {};
const deleteStaff = (params) => {};
module.exports = {
  create,
  fetchAll,
  findOne,
  deleteStaff,
  update,
};
