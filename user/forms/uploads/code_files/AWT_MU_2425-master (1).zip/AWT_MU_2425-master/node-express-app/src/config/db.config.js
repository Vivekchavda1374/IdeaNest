const MYSQL_DB_CONFIG = {
  HOST: "localhost",
  USER: "root",
  PORT: 3306,
  PASSWORD: "",
  DB: "student_mgnt_db",
};
module.exports = {
  MYSQL_DB_CONFIG,
};
