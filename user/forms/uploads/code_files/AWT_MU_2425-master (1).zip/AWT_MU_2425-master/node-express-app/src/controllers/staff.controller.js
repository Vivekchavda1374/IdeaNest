const staffService = require("../services/staff.service");
exports.create = (req, res) => {
  staffService.create();
};
exports.fetchAll = (req, res) => {};
exports.fetchOne = (req, res) => {};
exports.update = (req, res) => {};
exports.delete = (req, res) => {};
