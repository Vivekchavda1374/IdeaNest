import React from "react";

const Message = () => {
  return <div>Hi first message</div>;
};

export default Message;
