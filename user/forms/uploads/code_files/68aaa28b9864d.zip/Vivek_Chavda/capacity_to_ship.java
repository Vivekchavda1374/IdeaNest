class Solution {
    public int calculate(int[] weights, int mid) {
        int sum = 0;
        int days = 1;
        for (int wt : weights) {
            if (sum + wt > mid) {
                sum = 0;
                days++;
            }
            sum += wt;
        }
        return days;
    }

    public int shipWithinDays(int[] weights, int days) {
        int lo = 0;
        int hi = 0;
        for (int wt : weights) {
            hi += wt;
            lo = Math.max(lo, wt);
        }
        while (lo < hi) {
            int mid = lo + (hi - lo) / 2;
            int requiredDays = calculate(weights, mid);
            if (requiredDays <= days) {
                hi = mid;
            } else {
                lo = mid + 1;
            }
        }
        return lo;
    }
}