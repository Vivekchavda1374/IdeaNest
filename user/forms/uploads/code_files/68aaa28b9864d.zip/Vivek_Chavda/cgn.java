public class Solution {
    long MOD = 1000000007;

    public long modPow(long base, long exp) {
        if (exp == 0) return 1;
        long half = modPow(base, exp / 2);
        long result = (half * half) % MOD;
        if (exp % 2 == 1) result = (result * base) % MOD;
        return result;
    }

    public int countGoodNumbers(long n) {
        long evenCount = (n + 1) / 2;
        long oddCount = n / 2;
        long res = (modPow(5, evenCount) * modPow(4, oddCount)) % MOD;
        return (int) res;
    }
}