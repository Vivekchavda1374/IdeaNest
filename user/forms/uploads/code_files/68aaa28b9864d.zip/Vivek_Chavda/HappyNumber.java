class Solution {
    public boolean isHappy(int n) {
        int a = n;
        int b = n;
        do {
            a = Sum(a);
            b = Sum(Sum(b));
        } while (a != b);
        return a == 1;
    }

    private static int Sum(int num) {
        int sum = 0;
        while (num > 0) {
            int digit = num % 10;
            sum += digit * digit;
            num /= 10;
        }
        return sum;
    }
}